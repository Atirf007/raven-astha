---
name: code-review-lite
description: Use this skill whenever asked to review a pull request, diff, or set of changes. Trigger on phrases like "review this PR", "check this diff", "does this code look right". Reviews the diff and its direct dependencies only — never re-reads the whole repository — to keep reviews fast and cheap while still catching real issues.
---

# Code Review Lite

## Escopo da revisão

1. Leia **apenas o diff** primeiro (`git diff`, `git diff main...HEAD`, ou o
   diff fornecido).
2. Para cada trecho alterado, abra **só os arquivos diretamente
   referenciados** (a função chamada, a interface implementada) — não o
   repositório inteiro.
3. Não leia arquivos não relacionados "para ter contexto geral" a menos que
   o diff realmente dependa deles.

## Checklist (nessa ordem, pare cedo se achar problema bloqueante)

1. **Corretude** — a mudança faz o que a descrição/PR diz que faz?
2. **Segurança** — inputs não validados, segredos hardcoded, injeção,
   permissões abertas demais.
3. **Bugs óbvios** — off-by-one, null/undefined não tratado, condição de
   corrida evidente.
4. **Testes** — a mudança tem teste cobrindo o caso novo? Testes existentes
   ainda fazem sentido?
5. **Legibilidade/manutenibilidade** — só aponte se genuinamente dificulta
   manutenção futura, não por preferência de estilo pessoal.
6. **Performance** — só se o diff está em um caminho conhecido como quente
   (hot path); não investigue performance de código não tocado.

## Formato de saída

Liste só o que precisa de ação, agrupado por severidade:

```
## Bloqueante
- arquivo.py:42 — <problema e por quê>

## Sugestão
- arquivo.py:58 — <problema e por quê>

## Sem problemas encontrados em: <lista curta se aplicável>
```

Não narre o processo de revisão ("primeiro eu olhei X, depois Y"). Não
elogie o código extensamente — se está bom, diga "sem problemas
encontrados" e siga.

## Quando expandir o escopo

Só leia mais do repositório se o diff alterar uma assinatura pública (API,
schema, contrato entre módulos) — nesse caso, busque (não leia tudo) os
call sites afetados com `rg` antes de aprovar.
