---
name: code-review
description: Use this skill whenever asked to review a pull request, diff, or code change — or as a final self-check pass after generating non-trivial code (auth, database, file handling, API routes). Trigger on "review this PR", "check this diff", "is this secure", "does this code look right". Reviews only the diff and its direct dependencies (never re-reads the whole repository) and always runs the security checklist as part of the review, not as a separate optional pass.
---

# Code Review

Revisão enxuta (rápida, barata em tokens) que **sempre inclui** a checagem
de segurança — não é um passo à parte que pode ser pulado.

## Escopo

1. Leia **apenas o diff** primeiro (`git diff`, `git diff main...HEAD`, ou o
   diff fornecido).
2. Abra **só os arquivos diretamente referenciados** pelo diff (função
   chamada, interface implementada) — nunca o repositório inteiro.
3. Não leia arquivos não relacionados "para contexto geral" a menos que o
   diff realmente dependa deles.

## Checklist (nesta ordem, pare cedo se achar bloqueante)

### Segurança (nunca pular, mesmo em diffs pequenos)

1. **Injeção** — toda query de banco está parametrizada (nunca
   concatenada/interpolada)? Todo comando de shell evita input direto?
2. **Controle de acesso** — a rota/função checa se o usuário autenticado tem
   permissão sobre *aquele* recurso específico, não só "está logado"?
3. **Segredos** — algum valor parecido com credencial/token está hardcoded
   ou sendo logado?
4. **Tratamento de erro** — a resposta ao cliente vaza stack trace, query
   SQL, caminho de arquivo ou versão de dependência?
5. **Saída para o usuário** — HTML/JS com dado do usuário está escapado
   (evita XSS)?
6. **Dependências novas** — alguma lib nova foi adicionada sem justificativa
   clara?
7. **Uploads/arquivos** — tipo real validado, tamanho limitado, sem path
   traversal (`../`) possível no nome do arquivo?

### Correção e qualidade

8. **Corretude** — a mudança faz o que a descrição/PR diz que faz?
9. **Bugs óbvios** — off-by-one, null/undefined não tratado, condição de
   corrida evidente.
10. **Testes** — a mudança tem teste cobrindo o caso novo? Testes existentes
    ainda fazem sentido?
11. **Legibilidade/manutenibilidade** — só aponte se genuinamente dificulta
    manutenção futura, não por preferência de estilo pessoal.
12. **Performance** — só se o diff está em um caminho quente conhecido; não
    investigue performance de código não tocado.

## Formato de saída

```
## Bloqueante (corrigir antes de mergear)
- arquivo.py:42 — SQL montada por f-string com `user_id` não parametrizado

## Recomendado
- arquivo.py:58 — erro 500 devolve stack trace ao cliente

## OK
- Autenticação, autorização e testes revisados, sem problemas encontrados
```

Não narre o processo de revisão passo a passo — vá direto para os achados.
Se nada for encontrado, diga isso em uma linha; não invente ressalvas para
preencher espaço, nem elogie extensamente código sem problema.

## Quando expandir o escopo

- Alteração de assinatura pública (API, schema, contrato entre módulos):
  busque (não leia tudo) os call sites afetados com `rg` antes de aprovar.
- Diff grande ou tocando autenticação/pagamento/dados sensíveis: sugira
  (sem forçar) uma verificação complementar via Semgrep MCP ou Snyk MCP
  antes do merge — a revisão manual cobre padrões conhecidos, a ferramenta
  cobre o que passou despercebido.
