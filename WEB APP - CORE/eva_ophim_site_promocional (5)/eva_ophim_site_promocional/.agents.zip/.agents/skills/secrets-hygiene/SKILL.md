---
name: secrets-hygiene
description: Use this skill whenever writing code that involves API keys, passwords, tokens, database credentials, config files, environment variables, or anything that connects to an external service. Trigger before committing any config file, before adding a new integration, and when the user pastes a real-looking credential into the conversation. Prevents hardcoded secrets, leaked credentials, and insecure config defaults.
---

# Secrets Hygiene

## Regras obrigatórias

1. **Nunca escrever segredo real no código-fonte**, mesmo "temporariamente"
   ou em comentário. Use variáveis de ambiente (`os.environ`, `process.env`,
   etc.) ou um gerenciador de segredos (Vault, AWS Secrets Manager, Doppler,
   1Password CLI).
2. **Se o usuário colar uma chave/token real na conversa**, trate como
   comprometida: instrua a revogar e gerar uma nova, não apenas remover do
   código. Não repita a chave de volta desnecessariamente.
3. **Arquivos de exemplo (`.env.example`) contêm só nomes de variável**,
   nunca valores reais, nem valores "de mentirinha" parecidos com reais.
4. **`.env`, arquivos de credencial e chaves privadas vão no
   `.gitignore`** — ao criar um projeto novo, adicionar isso desde o
   primeiro commit, não depois.
5. **Nunca logar o valor de um segredo**, nem em log de debug. Se precisar
   confirmar que uma variável foi carregada, logar só que existe
   (`"DB_PASSWORD carregada: sim/não"`), nunca o valor.
6. **Segredos em CI/CD** vão em secret store da plataforma (GitHub Actions
   Secrets, GitLab CI Variables protegidas, etc.), nunca no YAML do
   pipeline em texto claro.
7. **Rotação**: ao gerar código que usa uma credencial de longa duração,
   sinalizar ao usuário se a API/serviço suporta credenciais de curta
   duração ou rotação automática, e preferir essa opção quando disponível.

## Checklist antes de qualquer commit

```bash
# Buscar por padrões comuns de segredo antes de commitar
rg -n "(api[_-]?key|secret|password|token)\s*=\s*['\"][A-Za-z0-9]{16,}"
rg -n "AKIA[0-9A-Z]{16}"                 # AWS access key
rg -n "-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----"
```

Qualquer resultado real precisa ser removido do histórico do git (não só do
arquivo atual — `git log` mantém), e a credencial precisa ser revogada.

## Padrão de configuração recomendado

```python
# CERTO — lê de variável de ambiente, falha alto se ausente
import os

DB_PASSWORD = os.environ["DB_PASSWORD"]  # levanta erro se não setada
```

```python
# ERRADO — segredo hardcoded
DB_PASSWORD = "hunter2"
```

Preferir falhar explicitamente (erro claro na inicialização) a usar um
valor padrão inseguro quando uma variável de segredo está ausente.

## Ferramentas complementares

- **GitHub secret scanning** (via MCP ou nativo do GitHub) — detecta
  credenciais vazadas antes do commit chegar ao histórico público.
- **`git-secrets` / `gitleaks`** como pre-commit hook, para pegar o que a
  busca manual acima não cobrir.
