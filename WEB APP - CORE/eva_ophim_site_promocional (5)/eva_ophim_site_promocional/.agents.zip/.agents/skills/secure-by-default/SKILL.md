---
name: secure-by-default
description: MANDATORY skill that MUST be consulted for every task that writes, edits, or generates code in this project — new features, bug fixes, refactors, endpoints, forms, database queries, file handling, authentication, or any code touching user input, external data, or a database. Trigger it even when the user does not mention security explicitly; secure defaults are not optional. Based on OWASP Top 10:2025 and OWASP ASVS 5.0. Do not skip this skill just because the task seems small — small endpoints are the most common source of real vulnerabilities.
---

# Secure by Default

Toda geração de código neste projeto segue este checklist como padrão, não
como extra. Se uma escolha aqui conflitar com o pedido do usuário, avise
explicitamente em vez de silenciosamente inserir uma falha de segurança.

## Checklist obrigatório antes de considerar o código pronto

1. **Toda entrada externa é hostil até prova em contrário** — parâmetros de
   URL, corpo de requisição, headers, cookies, arquivos enviados, variáveis
   de ambiente vindas de fora do processo, respostas de APIs de terceiros.
2. **Nunca construir queries de banco por concatenação/interpolação de
   string.** Sempre parametrizado. Ver skill `sql-injection-prevention`.
3. **Nunca montar comandos de shell com input do usuário sem
   sanitização/escaping via API segura da linguagem** (evitar `os.system`,
   `exec()`, `eval()`, template strings viradas comando).
4. **Nunca logar segredos, senhas, tokens ou dados sensíveis** em texto
   claro. Ver skill `secrets-hygiene`.
5. **Autenticação e autorização são checadas no servidor**, nunca confiadas
   só ao cliente/frontend. Toda rota que manipula dado de outro usuário
   precisa checar propriedade/permissão explicitamente (Broken Access
   Control é a categoria nº1 do OWASP Top 10:2025).
6. **Saída para HTML/JS é escapada** (evitar XSS) — usar o mecanismo de
   template do framework, nunca concatenar HTML com dado do usuário.
7. **Erros não vazam detalhes internos** ao usuário final (stack trace,
   query SQL, caminho de arquivo, versão de biblioteca) — logar detalhado
   no servidor, responder genérico ao cliente.
8. **Uploads de arquivo**: validar tipo real (não só extensão/mimetype
   declarado), limitar tamanho, nunca servir upload do mesmo domínio da
   aplicação sem isolamento (evita XSS via upload).
9. **Dependências novas**: antes de adicionar uma lib, preferir uma já usada
   no projeto; se for nova, mencionar ao usuário para revisão (supply
   chain). Ver skill `dependency-supply-chain`.
10. **Dados sensíveis em repouso**: senha sempre hasheada com algoritmo
    lento (bcrypt/argon2/scrypt), nunca MD5/SHA1 puro; dados sensíveis
    (PII, tokens) criptografados quando fizer sentido ao domínio.

## Categorias do OWASP Top 10:2025 (referência rápida)

| # | Categoria | O que checar ao gerar código |
|---|---|---|
| 1 | Broken Access Control | toda rota/query filtra pelo usuário autenticado correto |
| 2 | Security Misconfiguration | configs padrão inseguras, CORS aberto demais, debug ligado em prod |
| 3 | Supply Chain Failures | dependências não auditadas, versões travadas ausentes |
| 4 | Cryptographic Failures | algoritmo fraco, chave hardcoded, TLS ausente |
| 5 | Injection (SQL, comando, LDAP, etc.) | ver `sql-injection-prevention` |
| 6 | Insecure Design | falta de rate limit, falta de validação de regra de negócio |
| 7 | Authentication Failures | senha fraca aceita, sessão não expira, sem MFA onde crítico |
| 8 | Integrity Failures | deserialização insegura, atualização sem verificação de assinatura |
| 9 | Logging Failures | eventos de segurança não logados, ou segredo logado |
| 10 | Exception Handling | erro vaza stack trace/dados internos ao cliente |

Para o detalhamento completo (ASVS 5.0, riscos de LLM/Agentic AI, quirks por
linguagem), instale o skill oficial da comunidade:

```bash
npx degit agamm/claude-code-owasp/.claude/skills/owasp-security \
  .agents/skills/owasp-security
```

Esse pacote traz `owasp-report.md` com exemplos antes/depois por linguagem,
checklists de revisão e a rubrica de triagem de achados (confirmar que o
input é controlável pelo atacante e que o "sink" é alcançável antes de
reportar, para reduzir falso positivo).

## Ferramentas complementares (defesa em profundidade)

Skills e checklists cobrem o "como escrever certo desde o início". Para
verificação automatizada adicional, considere conectar (via
`suggest_connectors`/MCP, não obrigatório):

- **Semgrep MCP** — análise estática determinística com mais de 5.000
  regras, entende semântica de várias linguagens; roda `security_check` /
  `semgrep_scan` sobre o diff.
- **Snyk MCP** — inclui comando `/snyk-fix` e checagem de dependências
  vulneráveis.
- **GitHub secret scanning** (via MCP do GitHub) — pega credenciais
  vazadas antes do commit.

Essas ferramentas encontram o que passou despercebido; as skills deste kit
existem para reduzir a quantidade de problemas gerados em primeiro lugar.
