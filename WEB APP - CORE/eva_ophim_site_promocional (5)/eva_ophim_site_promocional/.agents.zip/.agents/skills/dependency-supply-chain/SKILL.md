---
name: dependency-supply-chain
description: Use this skill whenever adding a new dependency/package to the project, updating an existing dependency to a new major version, or when asked to audit dependencies for vulnerabilities. Trigger on "add a library", "install package", "npm install", "pip install", "update dependency", or similar. Prevents supply-chain risk from unvetted or malicious packages — OWASP Top 10:2025 category #3.
---

# Dependency & Supply Chain Security

## Antes de adicionar uma dependência nova

1. **Prefira o que já está no projeto.** Se o projeto já usa uma lib para
   algo similar, não adicione uma segunda concorrente para a mesma
   finalidade sem justificativa.
2. **Verifique sinais básicos de saúde do pacote** antes de sugerir:
   - Mantido recentemente (não abandonado há anos)?
   - Número de downloads/estrelas condizente com o que promete fazer?
   - Não é um pacote com nome quase idêntico a um popular (typosquatting —
     ex: `reqeusts` em vez de `requests`)?
3. **Nunca instale um pacote só porque "parece" ser o certo pelo nome** sem
   confirmar que é o pacote oficial/esperado.
4. **Trave a versão** (lockfile: `package-lock.json`, `poetry.lock`,
   `Gemfile.lock`, `go.sum`) — nunca deixe a instalação sem lockfile
   commitado.

## Ao atualizar dependências

- Ler o changelog/release notes de mudanças de versão major antes de
  aplicar, especialmente para libs de autenticação, criptografia, ou
  parsing de dados não confiáveis.
- Rodar a suíte de testes depois de qualquer atualização antes de
  considerar concluído.

## Auditoria periódica

```bash
# Node.js
npm audit
npm audit fix

# Python
pip install pip-audit && pip-audit

# Go
go list -json -m all | nancy sleuth   # ou govulncheck

# Ruby
bundle audit
```

Trate achados de severidade alta/crítica como bloqueantes; severidade
baixa/média pode ser registrada como débito técnico com prazo, não ignorada
silenciosamente.

## Sinais de alerta em um pacote (não instalar sem investigar)

- Scripts de `postinstall` que fazem chamada de rede.
- Pedido de permissões/escopo muito além do que a funcionalidade exige.
- Publicado há poucos dias, sem histórico, mas já sendo sugerido como
  dependência de produção.
- Código minificado/ofuscado dentro do pacote fonte (fora do build normal).

## Ferramentas complementares

- **Snyk MCP** — inclui checagem de dependências vulneráveis integrada ao
  fluxo do agente, com comando de correção assistida.
- **GitHub Dependabot / secret scanning** — alertas automáticos de CVE em
  dependências do repositório.
- **`npm audit` / `pip-audit` / `govulncheck` / `bundle audit`** — checagem
  local antes de cada release.
