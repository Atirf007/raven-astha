---
name: sql-injection-prevention
description: MUST be used whenever generating or editing any code that builds a database query, uses an ORM, or handles search/filter/sort parameters coming from user input — regardless of language or framework. Trigger on words like "query", "SELECT", "WHERE", "search", "filter", database access functions, or raw SQL strings. This is the single most common and most severe vulnerability class (OWASP Injection); never skip this check for "small" queries.
---

# SQL Injection Prevention

## Regra absoluta

**Nunca** monte uma query concatenando ou interpolando (f-string, `+`,
template literal, `.format()`) valores vindos de input externo diretamente
na string SQL. Sempre use parametrização/prepared statements ou o
query-builder seguro do ORM.

## Errado vs. certo por linguagem

### Python

```python
# ERRADO — injetável
query = f"SELECT * FROM users WHERE email = '{email}'"
cursor.execute(query)

# CERTO — parametrizado (DB-API 2.0 / psycopg2 / sqlite3)
cursor.execute("SELECT * FROM users WHERE email = %s", (email,))

# CERTO — ORM (SQLAlchemy)
db.session.query(User).filter(User.email == email).first()
```

### Node.js / TypeScript

```js
// ERRADO — injetável
const query = `SELECT * FROM users WHERE email = '${email}'`;
db.query(query);

// CERTO — parametrizado (node-postgres, mysql2)
db.query("SELECT * FROM users WHERE email = $1", [email]);

// CERTO — ORM (Prisma)
prisma.user.findFirst({ where: { email } });
```

### PHP

```php
// ERRADO — injetável
$query = "SELECT * FROM users WHERE email = '$email'";
$result = $mysqli->query($query);

// CERTO — prepared statement (PDO)
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
$stmt->execute(['email' => $email]);
```

### Java

```java
// ERRADO — injetável
String query = "SELECT * FROM users WHERE email = '" + email + "'";
stmt.executeQuery(query);

// CERTO — PreparedStatement
PreparedStatement stmt = conn.prepareStatement(
    "SELECT * FROM users WHERE email = ?");
stmt.setString(1, email);
```

### Go

```go
// ERRADO — injetável
query := fmt.Sprintf("SELECT * FROM users WHERE email = '%s'", email)
db.Query(query)

// CERTO — parametrizado (database/sql)
db.Query("SELECT * FROM users WHERE email = $1", email)
```

### Ruby

```ruby
# ERRADO — injetável
User.where("email = '#{email}'")

# CERTO — parametrizado / ActiveRecord
User.where(email: email)
User.where("email = ?", email)
```

## Casos que exigem atenção extra (armadilhas comuns)

- **Identificadores dinâmicos** (nome de tabela/coluna vindo de input):
  parametrização normal não cobre nomes de tabela/coluna. Nunca aceite
  nome de tabela/coluna livre do usuário — use uma allowlist fixa e mapeie
  o input para um valor da lista antes de montar a query.
- **ORDER BY dinâmico**: mesmo problema — valide contra uma allowlist de
  colunas permitidas, nunca interpole o valor direto.
- **Queries em lote / `IN (...)`**: use os placeholders múltiplos que a
  lib/driver oferece, não construa a lista via join de strings.
- **Stored procedures**: parametrizar a chamada não elimina o risco se a
  procedure internamente concatena SQL dinâmico — revisar a procedure
  também.
- **ORMs também são vulneráveis quando você foge do query-builder**: `raw()`,
  `.exec(sql_string)`, `text()` com f-string por dentro reintroduzem o
  problema — trate essas chamadas com o mesmo cuidado de SQL puro.
- **NoSQL não está imune**: MongoDB com operadores vindos direto do input
  (`{$where: userInput}` ou objetos de filtro montados sem validação de
  schema) tem uma classe análoga de injeção — valide/tipe o filtro.

## Defesa em profundidade (além da query)

1. **Usuário de banco com privilégio mínimo** — a conexão da aplicação não
   deveria ter `DROP`/`ALTER` se a aplicação só precisa de
   `SELECT/INSERT/UPDATE`.
2. **Validar tipo e formato do input** antes mesmo de chegar na query
   (e-mail parece e-mail, ID é numérico, etc.) — validação não substitui
   parametrização, mas reduz superfície.
3. **Mensagens de erro genéricas** para o cliente — nunca devolver o erro
   cru do driver de banco (ele pode vazar estrutura da tabela).
4. **Logar tentativas de query malformada** suspeitas para detecção, sem
   logar dados sensíveis do próprio usuário.

## Ao revisar código existente

Busque por padrões de risco antes de aprovar qualquer PR que toque acesso a
dados:

```bash
rg -n "SELECT.*\+|f\"SELECT|`SELECT.*\$\{|\.format\(.*SELECT" 
rg -n "\.raw\(|execute\(.*%|query\(.*\+"
```

Qualquer resultado precisa ser inspecionado manualmente — nem todo hit é
vulnerável, mas todo hit merece olhar.
