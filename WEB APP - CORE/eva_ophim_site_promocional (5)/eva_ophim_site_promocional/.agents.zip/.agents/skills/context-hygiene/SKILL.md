---
name: context-hygiene
description: Use this skill when a session has been running for a while — many tool calls, several unrelated subtasks completed, or context usage visibly climbing — to decide whether to keep going, summarize, or start a fresh session. Trigger it proactively before context usage gets high, not after the session is already struggling. Prevents expensive automatic history compaction and silent quality loss from an overloaded context window.
---

# Context Hygiene

Contexto lotado custa tokens de duas formas: (1) cada turno subsequente
carrega mais histórico, e (2) ao estourar o limite, o agente dispara uma
compactação automática que reenvia todo o histórico com um prompt de
sumarização dedicado — uma rodada inteira só para comprimir.

## Sinais de que é hora de agir

- A barra/indicador de uso de contexto está acima de ~70-80%.
- Você concluiu uma tarefa e a próxima é **não relacionada** (ex: terminou
  um bugfix e agora vai mexer em outro módulo do zero).
- O histórico contém múltiplas tentativas falhas/descartadas da mesma
  tarefa (rascunhos anteriores só ocupam espaço).
- Você está prestes a colar um arquivo grande ou saída de log extensa.

## O que fazer

1. **Entre tarefas não relacionadas:** feche a sessão atual e comece uma
   nova. Isso é a economia de maior impacto e mais rápida de aplicar —
   contexto zerado, sem histórico morto.
2. **Dentro da mesma tarefa, se o contexto está subindo:** peça/gera um
   resumo manual e conciso do progresso (decisões tomadas, estado atual,
   próximos passos) e continue a partir dele, em vez de deixar a
   compactação automática decidir o que preservar.
3. **Antes de colar algo grande** (log, arquivo extenso, saída de build):
   pergunte-se se só um trecho relevante resolve. Corte antes de colar, não
   depois.
4. **Não acumule tentativas descartadas no histórico.** Se uma abordagem
   falhou e foi abandonada, não é necessário manter os detalhes dela no
   contexto — um resumo de uma linha ("tentativa X não funcionou por Y")
   basta.

## Regra prática

> Se a próxima coisa que você vai fazer não depende de nada que aconteceu
> nas últimas N trocas, essa é a hora de encerrar a sessão, não de
> continuar "por comodidade".
