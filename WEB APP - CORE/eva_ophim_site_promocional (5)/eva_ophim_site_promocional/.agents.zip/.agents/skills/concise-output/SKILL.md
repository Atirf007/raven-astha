---
name: concise-output
description: Use this skill as the default communication style for every response in this project, especially code changes, command output summaries, and status updates. Always active unless the user explicitly asks for a detailed explanation, a tutorial, or documentation. Cuts output tokens by removing preamble, filler, and redundant restatement while preserving all technical substance.
---

# Concise Output

Objetivo: manter 100% da substância técnica, cortando tudo que não carrega
informação nova.

## Regras

1. **Sem preâmbulo.** Não comece com "Claro, vou fazer X" ou "Aqui está o que
   você pediu". Vá direto ao resultado.
2. **Sem repetir o pedido do usuário** antes de responder.
3. **Sem resumo redundante ao final** repetindo o que já foi mostrado no
   código/diff acima.
4. **Diffs em vez de arquivos inteiros** quando só uma parte mudou.
5. **Uma frase de status, não um parágrafo**, para confirmar que algo deu
   certo ("Testes passando. Cobertura 87%." em vez de um parágrafo
   comemorativo).
6. **Tabelas/listas em vez de prosa** quando a informação é estruturada
   (múltiplos arquivos alterados, múltiplos erros encontrados etc.).
7. **Não explicar decisões óbvias.** Explique só o que é não-trivial ou onde
   houve trade-off real.

## Quando NÃO aplicar (desative o modo conciso)

- O usuário pediu explicitamente uma explicação detalhada, um tutorial, ou
  documentação para outra pessoa ler.
- Está documentando uma decisão arquitetural importante que precisa de
  contexto para ser entendida depois.
- Está explicando um bug complexo onde o raciocínio importa tanto quanto a
  correção.

## Exemplo

**Verboso (evitar):**
> Claro! Vou analisar o código que você enviou e implementar a função que
> você pediu. Primeiro, vou explicar o que a função faz... [parágrafo]
> ...e aqui está o código completo do arquivo com a mudança: [arquivo
> inteiro] ...Para resumir, adicionei a validação de e-mail conforme
> solicitado, testei e está funcionando corretamente.

**Conciso (preferir):**
> Adicionada validação de e-mail em `services/user.py:42`.
> ```diff
> + if not EMAIL_RE.match(email):
> +     raise ValueError("email inválido")
> ```
> Testes: `pytest tests/test_user.py` — 4 passed.
