---
name: token-budget-router
description: Use this skill at the START of every task, before writing code or exploring files, to decide which model/profile and reasoning effort the task deserves. Trigger it whenever the user asks for a code change, bug fix, refactor, review, or any multi-step task — even if they don't mention cost or tokens. Skip it only for pure Q&A that needs no file access. This is the single highest-leverage habit for cutting token/dollar spend without losing quality, so use it proactively and don't wait to be asked.
---

# Token Budget Router

Objetivo: gastar tokens proporcionalmente à dificuldade real da tarefa, não
usar sempre o modelo/esforço mais caro "por segurança".

## Passo 1 — Classifique a tarefa

| Classe | Exemplos | Perfil recomendado |
|---|---|---|
| **Mecânica** | renomear variável, formatar, corrigir import, aplicar padrão já definido, atualizar changelog | modelo mais barato disponível, reasoning **baixo** |
| **Padrão** | implementar função já especificada, escrever teste unitário para código existente, pequeno bugfix com causa óbvia | modelo intermediário, reasoning **médio** |
| **Ambígua / arquitetural** | design de sistema, bug intermitente sem causa clara, decisão de trade-off, refactor amplo cruzando múltiplos módulos | modelo mais forte disponível, reasoning **alto** |

Se não tiver certeza da classe, comece assumindo **Padrão** e só suba para
Ambígua se a primeira tentativa falhar ou a incerteza for genuinamente alta.
Subir de nível é barato; começar sempre no nível mais alto é o desperdício
mais comum.

## Passo 2 — Aplique via profile do Codex CLI

Profiles são overlays de config selecionáveis com `--profile`, por exemplo:

```toml
# ~/.codex/cheap.config.toml
model = "<modelo mais barato configurado>"
model_reasoning_effort = "low"
```

```toml
# ~/.codex/frontier.config.toml
model = "<modelo mais forte configurado>"
model_reasoning_effort = "high"
```

Uso:

```bash
codex --profile cheap    "renomeie a variável X para Y em todo o arquivo"
codex --profile frontier "investigue por que o job trava intermitentemente às 3h"
```

Se o ambiente não tiver profiles configurados, comunique isso ao usuário uma
única vez e sugira criá-los — não force a criação sem permissão.

## Passo 3 — Não troque de perfil no meio da tarefa sem motivo

Uma sessão pode misturar subtarefas de dificuldades diferentes. É normal
subir o esforço no meio de uma tarefa Padrão que virou Ambígua, mas não
faça o inverso "para economizar" no meio de um raciocínio complexo já em
andamento — isso geralmente gera retrabalho, que custa mais tokens no total
do que ter usado o modelo certo desde o início.

## Regra de ouro

> Modelo forte = para trabalho ambíguo e de alto risco.
> Modelo barato = para edição mecânica, classificação de log, limpeza de
> um único arquivo.
> Usar o modelo mais caro para tudo é a versão cara da preguiça.
