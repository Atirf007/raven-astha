---
name: surgical-code-search
description: Use this skill whenever you need to understand, locate, or navigate code in this repository — before opening any file. Trigger it for "find where X is defined", "how does Y work", "fix this bug", "add a feature to Z", or any task requiring you to explore the codebase. Never read entire files or directories blindly when a structured search can find the relevant lines directly; this is a primary source of wasted tokens.
---

# Surgical Code Search

Regra central: **qualquer índice estruturado é melhor que leitura cega de
arquivo**. Nunca abra um arquivo inteiro só para achar uma função — ache a
linha primeiro, depois leia só o trecho necessário.

## Ordem de preferência de ferramentas

1. **Busca textual direcionada** (`rg`/`ripgrep`, `git grep`) — mais rápido e
   barato. Use para achar definições, usos, strings de erro, nomes de rotas.

   ```bash
   rg -n "def nome_da_funcao" --type py
   rg -n "class NomeDaClasse"
   git grep -n "TODO\|FIXME"
   ```

2. **Grafo de chamadas / símbolos** (se disponível: ctags, LSP, ferramenta
   de call-graph) — use quando a dúvida for "quem chama isso" ou "o que isso
   chama", em vez de abrir arquivo por arquivo tentando montar o grafo
   mentalmente.

3. **Busca semântica** ("onde fica a lógica de autenticação") — só quando as
   duas anteriores não resolvem, porque busca semântica geralmente custa
   mais tokens de setup. Prefira ainda assim delimitar por pasta.

4. **Leitura de arquivo inteiro** — último recurso, e mesmo assim prefira
   ler um intervalo de linhas (`view_range` / `sed -n 'A,Bp'`) quando você já
   sabe aproximadamente onde está o trecho relevante.

## Fluxo recomendado para qualquer tarefa de código

1. `rg` pelo símbolo/termo do pedido do usuário.
2. Ler só as ~30-60 linhas ao redor do resultado relevante.
3. Se precisar de mais contexto, expandir progressivamente (a função inteira
   → o arquivo → arquivos vizinhos), nunca pular direto para "ler tudo".
4. Antes de editar, confirmar que achou o lugar certo com uma segunda busca
   (ex: `rg` pelo nome da função para ver todos os call sites) em vez de
   assumir e editar às cegas.

## Anti-padrões a evitar

- Rodar `find /` ou listar `node_modules`, `dist`, `.git` sem necessidade.
- Abrir 10 arquivos "para ter certeza" quando 1 busca teria resolvido.
- Reler um arquivo que já está no contexto da conversa em vez de referenciar
  o que já foi visto.
- Buscas genéricas demais (`rg "user"`) quando um termo mais específico do
  próprio pedido do usuário resolveria com menos ruído.

## Quando vale montar um índice antes

Para repositórios grandes (dezenas de milhares de linhas) que serão tocados
repetidamente na mesma sessão, vale investir uma única vez em um índice
(ctags, um MCP de codebase-memory, ou um resumo de arquitetura salvo em
`references/architecture.md` dentro de uma skill do projeto) em vez de
refazer buscas amplas a cada nova pergunta.
